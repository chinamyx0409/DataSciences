import numpy as np
import matplotlib.pyplot as plt
plt.ion()                             # turns on the interactive mode
fig = plt.figure()
while True:
    data = np.random.random(20) 
    plt.axis([-1, len(data)+1, 0, 1]) # [xmin, xmax, ymin, ymax]
    for i in range(len(data)):    
        plt.bar(i, data[i], align = 'center')    
        plt.pause(0.5)                # draw the data and runs the GUI event loop    
    fig.clf()                         # plt.clf() clears the entire current figure with all its axes, but leaves the window opened, such that it may be reused for other plots.
while True:
    plt.pause(0.5)                    # keep the window after the data is plotted
    
# Press Ctrl-C to quit    