{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "import numpy as np\n",
    "import matplotlib.pyplot as plt\n",
    "import requests\n",
    "from requests.exceptions import HTTPError\n",
    "import json\n",
    "iterations = 100\n",
    "fig = plt.figure()\n",
    "plt.ion()\n",
    "plt.axis([0, iterations, -50, 50])\n",
    "place = 'Minneapolis'\n",
    "for i in range(iterations):  \n",
    "    # fetch the weather\n",
    "    try:\n",
    "        url = \"http://api.openweathermap.org/data/2.5/weather?q=\" + \\\n",
    "            place + \"&appid=3f63ccf4a308a813a06606c1bc526a16\"\n",
    "        response = requests.get(url)\n",
    "        # Raise an exception if a request is unsuccessful\n",
    "        response.raise_for_status()\n",
    "    except HTTPError as http_err:\n",
    "        print(f'HTTP error occurred: {http_err}')  \n",
    "    except Exception as err:\n",
    "        print(f'Other error occurred: {err}')  \n",
    "\n",
    "    else:\n",
    "        try:\n",
    "            weather = json.loads(response.text)    \n",
    "        except ValueError as err:  \n",
    "            print(err)\n",
    "        else:        \n",
    "            temp = weather[\"main\"][\"temp\"] - 273.15\n",
    "    plt.bar(i, temp)    \n",
    "    plt.pause(5)   # draw the data and runs the GUI event loop\n",
    "    \n",
    "while True:\n",
    "    plt.pause(0.5)   # keep the window after the data is plotted"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.5"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
