from matplotlib import pyplot as plt
import matplotlib.animation as animation
import time
import numpy as np
fig, ax = plt.subplots(1,1)
x= []
y = []
width = 20
def animate(i):
    x.append(i)
    y.append(np.random.random())
    ax.clear()
    if i > width:
        plt.axis([i - width, i+2, 0, 1])   # xmin, xmax, ymin, ymax
    ax.plot(x, y)
    ax.fill_between(x, y, 0, facecolor='blue', alpha=0.5) #fill in color
    
#----------------------------    
# The FuncAnimation() function makes an animation by repeatedly calling a function func    
#----------------------------
ani = animation.FuncAnimation(fig, animate, interval=750)
plt.show()
 # Press Q to quit